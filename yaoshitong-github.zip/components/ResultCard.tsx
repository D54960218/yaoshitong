"use client";

import { useState } from "react";
import VoiceControls from "@/components/VoiceControls";
import type { Medicine, VoiceStatus } from "@/lib/types";
import type { VerificationResult, VerificationCandidate } from "@/lib/verification";

interface Props {
  medicine: Medicine;
  voice: VoiceStatus;
  onSpeak: () => void;
  onStop: () => void;
}

function HeartIcon() {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M12 20s-6.5-4.3-8.4-8A4.8 4.8 0 0 1 12 6.6 4.8 4.8 0 0 1 20.4 12c-1.9 3.7-8.4 8-8.4 8Z" />
    </svg>
  );
}

function ClinicIcon() {
  return (
    <svg
      width="26"
      height="26"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <rect x="3.5" y="7" width="17" height="13" rx="2" />
      <path d="M9 7V5.2A1.2 1.2 0 0 1 10.2 4h3.6A1.2 1.2 0 0 1 15 5.2V7" />
      <path d="M12 11v5M9.5 13.5h5" />
    </svg>
  );
}

function Field({ label, value, danger = false }: { label: string; value: string; danger?: boolean }) {
  const empty = !value || value === "说明书未标注";
  return (
    <div>
      <p className={`field-label ${danger ? "field-label-danger" : ""}`}>{label}</p>
      <p className={`field-value ${empty ? "field-value-empty" : ""} ${danger && !empty ? "text-[var(--color-accent)]" : ""}`}>
        {empty ? "说明书未标注" : value}
      </p>
    </div>
  );
}

function VerificationIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M9 12l2 2 4-4" />
      <path d="M21 12c0 4.97-4.03 9-9 9s-9-4.03-9-9 4.03-9 9-9 9 4.03 9 9z" />
    </svg>
  );
}

function YiYuanVerificationPanel({
  verification,
  selected,
  onSelect,
}: {
  verification: VerificationResult;
  selected: VerificationCandidate | null;
  onSelect: (c: VerificationCandidate) => void;
}) {
  const [open, setOpen] = useState(false);

  const badgeClass =
    verification.status === "verified"
      ? "verify-badge-verified"
      : verification.status === "rejected"
        ? "verify-badge-error"
        : "verify-badge-warn";

  const statusColor =
    verification.status === "verified"
      ? "#155724"
      : verification.status === "rejected"
        ? "#721c24"
        : "#856404";

  return (
    <div className="verify-panel mt-5">
      <button
        type="button"
        className="verify-head"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
      >
        <span className={`verify-badge ${badgeClass}`}>
          <VerificationIcon />
          {verification.label} · {verification.score}分
        </span>
        <span className="verify-toggle">{open ? "收起" : "展开"}</span>
      </button>

      <p className="verify-summary" style={{ color: statusColor }}>
        {verification.humanNote}
      </p>

      {open && (
        <div className="verify-body">
          {verification.layer1Note && (
            <p className="verify-source-line">
              <b>第一层：</b>
              {verification.layer1Note}
            </p>
          )}
          {verification.layer2Note && (
            <p className="verify-source-line">
              <b>第二层：</b>
              {verification.layer2Note}
            </p>
          )}

          {verification.needsSelection && verification.candidates.length > 0 && (
            <div className="mt-4 space-y-3">
              <p className="field-label">请点击最符合药盒的一项：</p>
              {verification.candidates.map((c, idx) => {
                const isSelected =
                  selected &&
                  selected.drugName === c.drugName &&
                  selected.manufacturer === c.manufacturer &&
                  selected.specification === c.specification;
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => onSelect(c)}
                    className={`w-full rounded-lg border p-3 text-left transition-colors ${
                      isSelected
                        ? "border-[var(--color-primary)] bg-[var(--color-primary-tint)]"
                        : "border-[var(--color-line)] bg-white/25"
                    }`}
                  >
                    <p className="text-[23px] font-bold text-[var(--color-ink)]">{c.drugName}</p>
                    {c.manufacturer && (
                      <p className="mt-1 text-[21px] text-[var(--color-ink-soft)]">{c.manufacturer}</p>
                    )}
                    {c.specification && (
                      <p className="text-[21px] text-[var(--color-ink-soft)]">规格：{c.specification}</p>
                    )}
                    {c.approvalNumber && (
                      <p className="text-[21px] text-[var(--color-ink-soft)]">批准文号：{c.approvalNumber}</p>
                    )}
                    {isSelected && (
                      <p className="mt-2 text-[19px] font-bold text-[var(--color-primary)]">✓ 已选择</p>
                    )}
                  </button>
                );
              })}
            </div>
          )}

          <p className="verify-disclaimer">
            数据来自易源数据药品数据库，结果由代码规则自动裁决，仅供参考，不能替代医生和药盒说明书。
          </p>
        </div>
      )}
    </div>
  );
}

function VerificationPanel({ medicine }: { medicine: Medicine }) {
  const [open, setOpen] = useState(false);
  const verification = medicine.外部验证;
  if (!verification) return null;

  const verifiedCount = verification.sources.filter((s) => s.status === "hit").length;
  const badgeClass =
    verification.overall === "verified"
      ? "verify-badge-verified"
      : verification.overall === "failed"
        ? "verify-badge-error"
        : "verify-badge-warn";

  return (
    <div className="verify-panel mt-5">
      <button type="button" className="verify-head" onClick={() => setOpen((v) => !v)} aria-expanded={open}>
        <span className={`verify-badge ${badgeClass}`}>
          <VerificationIcon />
          {verification.overall === "verified" ? `已验证 · ${verifiedCount} 个数据库命中` : "外部验证"}
        </span>
        <span className="verify-toggle">{open ? "收起" : "展开"}</span>
      </button>

      <p className="verify-summary">{verification.humanNote}</p>

      {open && (
        <div className="verify-body">
          {verification.sources.map((s) => (
            <div key={s.source} className={`verify-source verify-source-${s.status}`}>
              <p className="verify-source-name">
                {s.source}
                <span className={`verify-source-tag tag-${s.status}`}>
                  {s.status === "hit" ? "命中" : s.status === "miss" ? "未命中" : "出错"}
                </span>
              </p>
              {s.genericName && s.genericName !== medicine.药名 && (
                <p className="verify-source-line">标准名：{s.genericName}</p>
              )}
              {(s.indications || s.dosage || s.contraindications || s.warnings) && (
                <div className="verify-source-fields">
                  {s.indications && <p><b>适应症：</b>{s.indications}</p>}
                  {s.dosage && <p><b>用法用量：</b>{s.dosage}</p>}
                  {s.contraindications && <p><b>禁忌：</b>{s.contraindications}</p>}
                  {s.warnings && <p><b>注意事项：</b>{s.warnings}</p>}
                  {s.route && <p><b>给药途径：</b>{s.route}</p>}
                  {s.dosageForm && <p><b>剂型：</b>{s.dosageForm}</p>}
                </div>
              )}
              {s.note && <p className="verify-source-note">{s.note}</p>}
            </div>
          ))}
          <p className="verify-disclaimer">以上数据来自海外/公开数据库，仅供交叉参考，不能替代医生和药盒说明书。</p>
        </div>
      )}
    </div>
  );
}

export default function ResultCard({ medicine, voice, onSpeak, onStop }: Props) {
  const [selectedCandidate, setSelectedCandidate] = useState<VerificationCandidate | null>(null);

  // 如果用户在候选列表里点选了一条，用该条数据库信息覆盖展示字段
  const displayMedicine: Medicine = selectedCandidate
    ? {
        ...medicine,
        药名: selectedCandidate.drugName || medicine.药名,
        规格: selectedCandidate.specification || medicine.规格,
        适应症: selectedCandidate.indications || medicine.适应症,
        用法用量: selectedCandidate.dosage || medicine.用法用量,
        禁忌: selectedCandidate.contraindications || medicine.禁忌,
        注意事项: selectedCandidate.warnings || medicine.注意事项,
        生产企业: selectedCandidate.manufacturer || medicine.生产企业,
        批准文号: selectedCandidate.approvalNumber || medicine.批准文号,
      }
    : medicine;

  return (
    <section className="card card-enter p-5">
      {/* 处方笺表头：双线 + 笺注 */}
      <div className="sheet-head">
        <h2 className="sheet-title">识别结果</h2>
        <p className="sheet-note">
          置信度 {displayMedicine.识别置信度}
          {displayMedicine.数据来源 ? ` · ${displayMedicine.数据来源}` : ""}
        </p>
      </div>

      <div className="mt-5">
        <VoiceControls status={voice} onSpeak={onSpeak} onStop={onStop} />
      </div>

      {/* 注射类药的场所提醒（后端确定性判定后下发，固定文案） */}
      {displayMedicine.注射提醒 && (
        <p className="inject-note mt-5" role="alert">
          <ClinicIcon />
          <span>{displayMedicine.注射提醒}</span>
        </p>
      )}

      {displayMedicine.是否处方药 && (
        <p className="rx-stamp mt-5" role="alert">
          ⚠ 该药为处方药
          <br />
          请务必咨询医生
        </p>
      )}
      {displayMedicine.通用信息 && <p className="note-banner mt-5">以下为通用信息，请核对药盒</p>}

      {/* 药名词条 */}
      <div className="mt-6">
        <h3 className="med-name">{displayMedicine.药名 || "未知名称"}</h3>
        <div className="med-name-rule" aria-hidden="true" />
      </div>

      {/* 字段：规则细线分隔 */}
      <dl className="mt-5 space-y-4">
        <Field label="规格" value={displayMedicine.规格} />
        {(displayMedicine.批准文号 || displayMedicine.生产企业) && (
          <div className="border-t border-[var(--color-line)] pt-4">
            {displayMedicine.批准文号 && <Field label="批准文号" value={displayMedicine.批准文号} />}
            {displayMedicine.生产企业 && (
              <div className={displayMedicine.批准文号 ? "mt-3" : ""}>
                <Field label="生产企业" value={displayMedicine.生产企业} />
              </div>
            )}
          </div>
        )}
        <div className="border-t border-[var(--color-line)] pt-4">
          <Field label="适应症" value={displayMedicine.适应症} />
        </div>
        <div className="border-t border-[var(--color-line)] pt-4">
          <Field label="用法用量" value={displayMedicine.用法用量} />
        </div>
        <div className="border-t border-[var(--color-line)] pt-4">
          <Field label="禁忌" value={displayMedicine.禁忌} danger />
        </div>
        <div className="border-t border-[var(--color-line)] pt-4">
          <Field label="注意事项" value={displayMedicine.注意事项} />
        </div>
      </dl>

      {/* AI 用大白话说的一句贴心提醒（语音也会念出来） */}
      {displayMedicine.贴心叮嘱 && (
        <p className="care-note mt-6">
          <HeartIcon />
          <span>{displayMedicine.贴心叮嘱}</span>
        </p>
      )}

      {/* 外部数据库交叉验证 */}
      <VerificationPanel medicine={medicine} />

      {/* 易源数据三层验证链路结果 */}
      {medicine.核验结果 && (
        <YiYuanVerificationPanel
          verification={medicine.核验结果}
          selected={selectedCandidate}
          onSelect={setSelectedCandidate}
        />
      )}
    </section>
  );
}
