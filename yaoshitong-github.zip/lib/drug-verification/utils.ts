import type { SourceDrugInfo, VerificationSource } from "./types";

/** 统一的失败响应工厂：不抛错，而是返回降级结果，避免拖垮主流程 */
export function miss(
  source: VerificationSource,
  drugName: string,
  note?: string,
): SourceDrugInfo {
  return {
    source,
    status: "miss",
    name: drugName,
    note: note || "未在外部数据库里找到这条药名，可能它不是常用药或名称写法不同。",
  };
}

export function error(
  source: VerificationSource,
  drugName: string,
  note?: string,
): SourceDrugInfo {
  return {
    source,
    status: "error",
    name: drugName,
    note: note || "外部数据库暂时连不上，已跳过验证。",
  };
}

/** 带超时保护的 fetch；超时或出错时返回 null */
export async function fetchWithTimeout(
  url: string,
  options: RequestInit = {},
  timeoutMs = 8000,
): Promise<Response | null> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      ...options,
      signal: controller.signal,
    });
    return res;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

/** 安全 JSON 解析 */
export async function safeJson<T>(res: Response | null): Promise<T | null> {
  if (!res || !res.ok) return null;
  try {
    return (await res.json()) as T;
  } catch {
    return null;
  }
}

/** 取数组里第一个非空字符串 */
export function firstString(...values: Array<string | string[] | undefined | null>): string | undefined {
  for (const v of values) {
    if (Array.isArray(v) && v.length > 0 && v[0]) return v[0];
    if (typeof v === "string" && v.trim()) return v.trim();
  }
  return undefined;
}

/** 把英文适应症/警告等浓缩成一句；数组取第一条，字符串去多余空格 */
export function normalizeEnglishText(value: string | string[] | undefined): string | undefined {
  const raw = firstString(value);
  if (!raw) return undefined;
  return raw
    .replace(/\s+/g, " ")
    .replace(/\[see [^\]]+\]/gi, "")
    .trim();
}
