import type { DrugVerification, SourceDrugInfo, VerificationSource } from "./types";
import * as openfda from "./adapters/openfda";
import * as rxnorm from "./adapters/rxnorm";
import * as dailymed from "./adapters/dailymed";
import * as unitcm from "./adapters/unitcm";

const ADAPTERS = [openfda, rxnorm, dailymed, unitcm];

/** 默认启用的验证来源（可通过环境变量 ENABLE_DRUG_VERIFICATION_SOURCES 覆盖） */
function enabledSources(): Set<VerificationSource> | null {
  const env = process.env.ENABLE_DRUG_VERIFICATION_SOURCES;
  if (!env) return null;
  const set = new Set<VerificationSource>(env.split(",").map((s) => s.trim() as VerificationSource));
  if (set.size === 0) return null;
  return set;
}

/** 并行调用所有启用的适配器，汇总成验证结果 */
export async function verifyDrug(drugName: string): Promise<DrugVerification> {
  const enabled = enabledSources();
  const adapters = ADAPTERS.filter((a) => (enabled ? enabled.has(a.name) : true));

  const results = await Promise.all(
    adapters.map(async (adapter) => {
      try {
        return await adapter.verify(drugName);
      } catch (e) {
        const note = e instanceof Error ? e.message : String(e);
        return {
          source: adapter.name,
          status: "error" as const,
          name: drugName,
          note: `验证出错：${note}`,
        };
      }
    }),
  );

  return summarize(drugName, results);
}

function summarize(drugName: string, sources: SourceDrugInfo[]): DrugVerification {
  const hits = sources.filter((s) => s.status === "hit");
  const errors = sources.filter((s) => s.status === "error");
  const misses = sources.filter((s) => s.status === "miss");

  const overall: DrugVerification["overall"] =
    hits.length > 0 ? "verified" : errors.length === sources.length ? "failed" : "unverified";

  // 找一个最一致的通用名
  const names = hits
    .map((s) => s.genericName || s.name)
    .filter((n): n is string => !!n && n !== drugName);
  const canonicalName = names.length > 0 ? names[0] : drugName;

  // 一致性：高=至少 2 个命中且通用名相似；中=1 个命中；低=0 命中
  let consistency: DrugVerification["consistency"] = "low";
  if (hits.length >= 2) {
    consistency = "high";
  } else if (hits.length === 1) {
    consistency = "medium";
  }

  const humanNote = buildHumanNote(drugName, hits, misses, errors);

  return {
    queriedName: drugName,
    sources,
    overall,
    canonicalName,
    consistency,
    humanNote,
  };
}

function buildHumanNote(
  drugName: string,
  hits: SourceDrugInfo[],
  misses: SourceDrugInfo[],
  errors: SourceDrugInfo[],
): string {
  if (hits.length === 0) {
    if (errors.length > 0 && misses.length === 0) {
      return `外部数据库暂时连不上，无法验证「${drugName}」，请以 AI 识别结果和药盒说明书为准。`;
    }
    return `未在免费公开数据库里找到「${drugName}」的权威记录，这可能是非美国上市药或中药，请以药盒说明书为准。`;
  }

  const names = hits.map((s) => s.genericName || s.name).filter(Boolean);
  const uniqueNames = Array.from(new Set(names));
  const namePart =
    uniqueNames.length > 1
      ? `外部数据库确认该药名为「${uniqueNames[0]}」，部分来源也写作「${uniqueNames.slice(1).join("、")}」。`
      : `外部数据库确认该药名为「${uniqueNames[0] || drugName}」。`;

  const sources = hits.map((s) => s.source).join("、");
  const warningPart =
    misses.length > 0
      ? `另有 ${misses.length} 个数据库未命中或未覆盖。`
      : "";

  return `${namePart}验证来源：${sources}。${warningPart}信息仅供参考，实际用药请遵医嘱。`;
}

/** 判断中药/西药：简单按药名后缀 */
export function guessDrugType(name: string): "chinese" | "western" | "unknown" {
  const cnPatterns = /丸|散|膏|丹|汤|饮|茶|贴|片仔癀|阿胶|人参|黄芪|甘草|当归|柴胡/i;
  const westPatterns = /胶囊|片|颗粒|注射液|口服液|糖浆|混悬液|肠溶|缓释|控释|分散/i;
  if (cnPatterns.test(name) && !westPatterns.test(name)) return "chinese";
  if (westPatterns.test(name)) return "western";
  return "unknown";
}
