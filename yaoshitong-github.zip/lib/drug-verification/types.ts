/**
 * 药品外部数据库验证层类型定义。
 *
 * 设计思路：
 * - 把 AI 识别结果与多个权威/公开数据库做交叉验证；
 * - 不直接覆盖 AI 结果，而是作为「外部参考」展示给老人/家属；
 * - 每个来源独立失败降级，互不影响。
 */

/** 已确认可免费、立即调用的外部来源 */
export type VerificationSource =
  | "openFDA"
  | "RxNorm"
  | "DailyMed"
  | "UniTCM";

/** 单个来源的验证状态 */
export type VerificationStatus = "hit" | "miss" | "error";

/** 单个来源返回的药品信息（都是可选的，因为不同库字段差异大） */
export interface SourceDrugInfo {
  /** 来源名称 */
  source: VerificationSource;
  /** 是否命中 */
  status: VerificationStatus;
  /** 标准药名（外部库里的名称） */
  name?: string;
  /** 通用名/活性成分 */
  genericName?: string;
  /** 商品名 */
  brandName?: string;
  /** 适应症 */
  indications?: string;
  /** 用法用量 */
  dosage?: string;
  /** 禁忌 */
  contraindications?: string;
  /** 注意事项/警告 */
  warnings?: string;
  /** 规格/剂量形态 */
  strength?: string;
  /** 给药途径 */
  route?: string;
  /** 剂型 */
  dosageForm?: string;
  /** 是否处方药（仅 openFDA 有可靠字段） */
  isRx?: boolean;
  /** 额外说明/错误信息 */
  note?: string;
}

/** 汇总后的验证结果，挂在 Medicine 上一起返回前端 */
export interface DrugVerification {
  /** 被验证的药名 */
  queriedName: string;
  /** 各来源原始结果 */
  sources: SourceDrugInfo[];
  /** 综合状态：至少一个来源命中 / 全部未命中 / 全部出错 */
  overall: "verified" | "unverified" | "failed";
  /** 从所有命中来源里合并出的标准名（最一致的） */
  canonicalName?: string;
  /** 一致性摘要：高=各来源主要信息基本一致；中=部分一致；低=冲突或无 */
  consistency: "high" | "medium" | "low";
  /** 给老人的一句人话提示 */
  humanNote: string;
}

/** 适配器统一接口 */
export interface DrugVerificationAdapter {
  name: VerificationSource;
  verify(drugName: string): Promise<SourceDrugInfo>;
}
