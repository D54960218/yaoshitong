import type { SourceDrugInfo } from "../types";
import { error, fetchWithTimeout, miss, normalizeEnglishText, safeJson } from "../utils";

interface DailyMedSpl {
  setid?: string;
  title?: string;
  published_date?: string;
}

interface DailyMedSearch {
  data?: DailyMedSpl[];
  metadata?: { total_elements?: number };
}

interface DailyMedLabelData {
  title?: string;
  indications_and_usage?: string[];
  dosage_and_administration?: string[];
  contraindications?: string[];
  warnings?: string[];
  warnings_and_cautions?: string[];
  package_label_principal_display_panel?: string[];
  openfda?: {
    brand_name?: string[];
    generic_name?: string[];
    product_type?: string[];
    route?: string[];
    dosage_form?: string[];
  };
}

interface DailyMedLabel {
  data?: DailyMedLabelData;
}

export const name = "DailyMed" as const;

export async function verify(drugName: string): Promise<SourceDrugInfo> {
  const searchUrl = `https://dailymed.nlm.nih.gov/dailymed/services/v2/spls.json?drug_name=${encodeURIComponent(drugName)}&pagesize=1`;
  const searchRes = await fetchWithTimeout(searchUrl, {}, 8000);
  const search = await safeJson<DailyMedSearch>(searchRes);

  if (!search?.data || search.data.length === 0) {
    return miss(name, drugName, "DailyMed 未找到该药名标签，可能未在美国上市或名称不同。");
  }

  const setid = search.data[0].setid;
  if (!setid) {
    return miss(name, drugName);
  }

  const labelUrl = `https://dailymed.nlm.nih.gov/dailymed/services/v2/spls/${setid}.json`;
  const labelRes = await fetchWithTimeout(labelUrl, {}, 8000);
  const label = await safeJson<DailyMedLabel>(labelRes);
  const d = label?.data;

  if (!d) {
    return {
      source: name,
      status: "hit",
      name: drugName,
      note: "DailyMed 搜索到了记录，但未能获取完整标签内容。",
    };
  }

  const openfda = d.openfda ?? {};

  return {
    source: name,
    status: "hit",
    name: drugName,
    genericName: normalizeEnglishText(openfda.generic_name),
    brandName: normalizeEnglishText(openfda.brand_name),
    indications: normalizeEnglishText(d.indications_and_usage),
    dosage: normalizeEnglishText(d.dosage_and_administration),
    contraindications: normalizeEnglishText(d.contraindications),
    warnings: normalizeEnglishText(d.warnings ?? d.warnings_and_cautions),
    route: normalizeEnglishText(openfda.route),
    dosageForm: normalizeEnglishText(openfda.dosage_form),
    isRx: openfda.product_type?.some((t) => /prescription/i.test(t)),
    note: `来自 DailyMed（NLM 官方药品标签库）。`,
  };
}
