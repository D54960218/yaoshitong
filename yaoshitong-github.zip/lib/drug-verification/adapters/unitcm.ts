import type { SourceDrugInfo } from "../types";
import { fetchWithTimeout, miss, safeJson } from "../utils";

interface UniTCMHerb {
  unitcm_herb_id?: number;
  herb_chinese_name?: string | null;
  herb_english_name?: string | null;
  herb_latin_name?: string | null;
  family?: string | null;
  therapeutic_en_class?: string | null;
  toxicity?: string | null;
}

interface UniTCMSearch {
  items?: UniTCMHerb[];
  total?: number;
  page?: number;
  page_size?: number;
}

export const name = "UniTCM" as const;

export async function verify(drugName: string): Promise<SourceDrugInfo> {
  // UniTCM 目前面向中药；如果药名明显是西药，直接跳过，减少无效请求
  const westernHints = /胶囊|片|颗粒|注射液|口服液|糖浆|混悬液|肠溶|缓释|控释|分散/i;
  if (westernHints.test(drugName) && !/丸|散|膏|汤|饮|茶/i.test(drugName)) {
    return miss(name, drugName, "UniTCM 主要收录中药/中药材，该药名看起来是西药，已跳过。");
  }

  const url = `https://unitcm.qfxulab.com/api/v1/herbs?q=${encodeURIComponent(drugName)}&page=1&page_size=1`;
  const res = await fetchWithTimeout(url, {}, 8000);
  const data = await safeJson<UniTCMSearch>(res);

  const herb = data?.items?.[0];
  if (!herb) {
    return miss(name, drugName, "UniTCM 未找到对应中药/草药信息。");
  }

  const cnName = herb.herb_chinese_name ?? "";
  const enName = herb.herb_english_name ?? "";
  const latinName = herb.herb_latin_name ?? "";

  const isMatch =
    cnName.includes(drugName) ||
    drugName.includes(cnName) ||
    enName.toLowerCase().includes(drugName.toLowerCase()) ||
    latinName.toLowerCase().includes(drugName.toLowerCase());

  if (!isMatch) {
    return miss(name, drugName, `UniTCM 找到近似记录「${cnName || enName}」，但与药名不完全匹配。`);
  }

  const info: string[] = [];
  if (herb.family) info.push(`科属：${herb.family}`);
  if (herb.therapeutic_en_class) info.push(`分类：${herb.therapeutic_en_class}`);
  if (herb.toxicity) info.push(`毒性：${herb.toxicity}`);

  return {
    source: name,
    status: "hit",
    name: drugName,
    genericName: cnName || enName,
    warnings: info.length > 0 ? info.join("；") : undefined,
    note: "来自 UniTCM 中医药多组学平台（中药/草药信息）。",
  };
}
