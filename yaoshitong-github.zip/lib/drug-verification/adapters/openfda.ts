import type { SourceDrugInfo } from "../types";
import { error, fetchWithTimeout, miss, normalizeEnglishText, safeJson } from "../utils";

interface OpenFDALabel {
  indications_and_usage?: string[];
  dosage_and_administration?: string[];
  contraindications?: string[];
  warnings?: string[];
  warnings_and_cautions?: string[];
  openfda?: {
    brand_name?: string[];
    generic_name?: string[];
    product_type?: string[];
    route?: string[];
    dosage_form?: string[];
  };
}

interface OpenFDAResponse {
  results?: OpenFDALabel[];
}

export const name = "openFDA" as const;

export async function verify(drugName: string): Promise<SourceDrugInfo> {
  // 优先用通用名搜；如果药名带商品名，openfda.generic_name 也可能命中
  const apiKey = process.env.OPENFDA_API_KEY;
  const params = new URLSearchParams({
    search: `openfda.generic_name:"${drugName}"`,
    limit: "1",
  });
  if (apiKey) params.append("api_key", apiKey);

  const url = `https://api.fda.gov/drug/label.json?${params.toString()}`;
  const res = await fetchWithTimeout(url, {}, 10000);
  const data = await safeJson<OpenFDAResponse>(res);

  if (!data || !data.results || data.results.length === 0) {
    return miss(name, drugName, "openFDA 未收录该通用名，可能是非美国上市药品或药名写法不同。");
  }

  const r = data.results[0];
  const openfda = r.openfda ?? {};
  const generic = normalizeEnglishText(openfda.generic_name);

  return {
    source: name,
    status: "hit",
    name: drugName,
    genericName: generic,
    brandName: normalizeEnglishText(openfda.brand_name),
    indications: normalizeEnglishText(r.indications_and_usage),
    dosage: normalizeEnglishText(r.dosage_and_administration),
    contraindications: normalizeEnglishText(r.contraindications),
    warnings: normalizeEnglishText(r.warnings ?? r.warnings_and_cautions),
    route: normalizeEnglishText(openfda.route),
    dosageForm: normalizeEnglishText(openfda.dosage_form),
    isRx: openfda.product_type?.some((t) => /prescription/i.test(t)),
    note: `来自 openFDA（美国 FDA 公开药品标签）${apiKey ? "" : "，当前未使用 API Key，限流 240/分钟"}。`,
  };
}
