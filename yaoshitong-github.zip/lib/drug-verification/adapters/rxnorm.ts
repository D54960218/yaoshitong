import type { SourceDrugInfo } from "../types";
import { error, fetchWithTimeout, miss, safeJson } from "../utils";

interface RxNormIdGroup {
  idGroup?: {
    rxnormId?: string[];
    name?: string;
  };
}

interface RxNormProperty {
  properties?: {
    name?: string;
    synonym?: string;
    rxcui?: string;
    tty?: string;
  };
}

interface RxNormRelated {
  relatedGroup?: {
    conceptGroup?: Array<{
      tty?: string;
      conceptProperties?: Array<{
        name?: string;
        rxcui?: string;
        tty?: string;
      }>;
    }>;
  };
}

export const name = "RxNorm" as const;

export async function verify(drugName: string): Promise<SourceDrugInfo> {
  // 1. 先拿 rxcui
  const lookupUrl = `https://rxnav.nlm.nih.gov/REST/rxcui.json?name=${encodeURIComponent(drugName)}&search=2`;
  const lookupRes = await fetchWithTimeout(lookupUrl, {}, 8000);
  const lookup = await safeJson<RxNormIdGroup>(lookupRes);
  const rxcui = lookup?.idGroup?.rxnormId?.[0];

  if (!rxcui) {
    return miss(name, drugName, "RxNorm 未找到对应标准编码，可能是药名写法不规范或非美国上市药。");
  }

  // 2. 拿标准名和相关信息
  const propsUrl = `https://rxnav.nlm.nih.gov/REST/rxcui/${rxcui}/properties.json`;
  const relatedUrl = `https://rxnav.nlm.nih.gov/REST/rxcui/${rxcui}/related.json?tty=IN+PIN+SCD+SBD`;

  const [propsRes, relatedRes] = await Promise.all([
    fetchWithTimeout(propsUrl, {}, 8000),
    fetchWithTimeout(relatedUrl, {}, 8000),
  ]);

  const props = await safeJson<RxNormProperty>(propsRes);
  const related = await safeJson<RxNormRelated>(relatedRes);

  const standardName = props?.properties?.name ?? lookup.idGroup?.name ?? drugName;

  // 从 related 里找剂型和给药途径线索
  const forms: string[] = [];
  const routes: string[] = [];
  for (const group of related?.relatedGroup?.conceptGroup ?? []) {
    for (const cp of group.conceptProperties ?? []) {
      const n = cp.name ?? "";
      // 常见剂型关键词
      if (/\b(Tablet|Capsule|Injection|Solution|Suspension|Cream|Ointment|Gel|Inhaler|Patch|Drop|Powder|Granule)\b/i.test(n)) {
        forms.push(n.replace(/.*\b(Tablet|Capsule|Injection|Solution|Suspension|Cream|Ointment|Gel|Inhaler|Patch|Drop|Powder|Granule)\b.*/i, "$1"));
      }
      if (/\b(Oral|Intravenous|Topical|Subcutaneous|Intramuscular|Ophthalmic|Nasal|Rectal|Vaginal|Inhalation)\b/i.test(n)) {
        routes.push(n.replace(/.*\b(Oral|Intravenous|Topical|Subcutaneous|Intramuscular|Ophthalmic|Nasal|Rectal|Vaginal|Inhalation)\b.*/i, "$1"));
      }
    }
  }

  const unique = (arr: string[]) => Array.from(new Set(arr));

  return {
    source: name,
    status: "hit",
    name: drugName,
    genericName: standardName,
    dosageForm: unique(forms).slice(0, 3).join(", ") || undefined,
    route: unique(routes).slice(0, 3).join(", ") || undefined,
    note: `RxNorm 标准编码 ${rxcui}，确认该药名在美国临床术语库中存在。`,
  };
}
