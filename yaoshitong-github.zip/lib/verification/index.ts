/**
 * 药品识别结果三层验证链路。
 *
 * 链路：GLM 识别 → 第一层批准文号核验 → 第二层说明书字段核验 → 第三层置信度裁决 → 输出分级结果
 * 核心原则：GLM 只提假设，数据库 API 提供证据，代码负责比对、打分、裁决。模型不做判断。
 */

import {
  getVerdict,
  isDrugNameMatch,
  isManufacturerMatch,
  isSpecificationMatch,
  SCORE_RULES,
  verdictLabel,
} from "./rules";
import { searchByApprovalNumber, searchByDrugName, type YiYuanDrug } from "./yiyuan";

export type VerificationStatus = "verified" | "partial" | "confirm" | "rejected";

export interface VerificationCandidate {
  /** 数据库里的药品名称 */
  drugName: string;
  /** 通用名 */
  genericName?: string;
  /** 商品名 */
  brandName?: string;
  /** 批准文号 */
  approvalNumber?: string;
  /** 生产企业 */
  manufacturer?: string;
  /** 规格 */
  specification?: string;
  /** 适应症 */
  indications?: string;
  /** 用法用量 */
  dosage?: string;
  /** 禁忌 */
  contraindications?: string;
  /** 注意事项 */
  warnings?: string;
}

export interface VerificationResult {
  status: VerificationStatus;
  label: string;
  score: number;
  /** 数据库修正后的药名（如果第一层修正了） */
  correctedDrugName?: string;
  /** 是否需要用户从候选列表中选择 */
  needsSelection: boolean;
  /** 候选列表（confirm 状态时返回） */
  candidates: VerificationCandidate[];
  /** 匹配到的最佳记录（verified/partial 时返回） */
  bestMatch?: VerificationCandidate;
  /** 人类可读说明 */
  humanNote: string;
  /** 第一层状态说明 */
  layer1Note?: string;
  /** 第二层状态说明 */
  layer2Note?: string;
}

interface VerifierInput {
  glmDrugName: string;
  glmApprovalNumber?: string;
  glmManufacturer?: string;
  glmSpecification?: string;
}

/** 主入口：执行三层验证链路 */
export async function verifyDrugChain(input: VerifierInput): Promise<VerificationResult> {
  const { glmDrugName, glmApprovalNumber, glmManufacturer, glmSpecification } = input;
  let score = 0;
  let correctedDrugName: string | undefined;
  let layer1Note: string | undefined;
  let layer2Note: string | undefined;
  let bestMatch: VerificationCandidate | undefined;
  let candidates: VerificationCandidate[] = [];

  // ==================== 第一层：批准文号核验（硬门槛） ====================
  if (glmApprovalNumber && glmApprovalNumber.trim() !== "" && glmApprovalNumber !== "未识别") {
    try {
      const list = await searchByApprovalNumber(glmApprovalNumber);
      if (list.length === 0) {
        return {
          status: "rejected",
          label: verdictLabel("rejected"),
          score: 0,
          needsSelection: false,
          candidates: [],
          humanNote: `批准文号「${glmApprovalNumber}」在药品数据库中查不到，识别结果可能不是正规药品。`,
          layer1Note: "批准文号查无记录",
        };
      }

      const first = list[0];
      const dbDrugName = first.tymc || first.drugName || "";

      if (isDrugNameMatch(dbDrugName, glmDrugName)) {
        score += SCORE_RULES.approvalNumberMatch;
        correctedDrugName = dbDrugName;
        bestMatch = normalizeCandidate(first);
        layer1Note = "批准文号存在且药名匹配";
      } else {
        score += SCORE_RULES.approvalNumberExists;
        correctedDrugName = dbDrugName;
        bestMatch = normalizeCandidate(first);
        layer1Note = "批准文号存在，但药名不匹配，已按数据库修正";
      }
    } catch (e) {
      layer1Note = `批准文号核验失败：${e instanceof Error ? e.message : String(e)}`;
    }
  } else {
    layer1Note = "缺少批准文号核验";
  }

  // ==================== 第二层：说明书字段核验 ====================
  try {
    const searchName = correctedDrugName || glmDrugName;
    const list = await searchByDrugName(searchName);

    if (list.length === 0) {
      layer2Note = "药名在说明书库中未找到";
    } else {
      // 把所有结果作为候选；优先用和批准文号一致的那条作为最佳匹配
      candidates = list.map(normalizeCandidate);
      const matchedByApproval = glmApprovalNumber
        ? candidates.find(
            (c) =>
              c.approvalNumber &&
              (c.approvalNumber === glmApprovalNumber || c.approvalNumber.includes(glmApprovalNumber)),
          )
        : undefined;
      bestMatch = matchedByApproval || candidates[0];

      score += SCORE_RULES.drugNameInDB;
      layer2Note = "药名在说明书库中存在";

      // 生产企业匹配
      if (
        glmManufacturer &&
        glmManufacturer !== "未识别" &&
        bestMatch.manufacturer &&
        isManufacturerMatch(bestMatch.manufacturer, glmManufacturer)
      ) {
        score += SCORE_RULES.manufacturerMatch;
        layer2Note += "，生产企业匹配";
      }

      // 规格匹配
      if (
        glmSpecification &&
        glmSpecification !== "未识别" &&
        bestMatch.specification &&
        isSpecificationMatch(bestMatch.specification, glmSpecification)
      ) {
        score += SCORE_RULES.specificationMatch;
        layer2Note += "，规格匹配";
      }
    }
  } catch (e) {
    layer2Note = `说明书字段核验失败：${e instanceof Error ? e.message : String(e)}`;
  }

  // ==================== 第三层：置信度裁决 ====================
  const status = getVerdict(score);

  // confirm 状态：需要用户从候选列表中选
  if (status === "confirm" || (status === "partial" && candidates.length > 1)) {
    return {
      status: "confirm",
      label: verdictLabel("confirm"),
      score,
      correctedDrugName,
      needsSelection: true,
      candidates,
      bestMatch,
      humanNote: `数据库里找到 ${candidates.length} 个同名或相似药品，请点选最符合药盒的那一条。`,
      layer1Note,
      layer2Note,
    };
  }

  const label = verdictLabel(status);
  let humanNote = "";
  switch (status) {
    case "verified":
      humanNote = `数据库核验通过（${score} 分），药名、规格/企业等关键字段与数据库一致。`;
      break;
    case "partial":
      humanNote = `部分字段已验证（${score} 分），仍建议您核对药盒说明书。`;
      break;
    case "rejected":
      humanNote = `数据库核验未通过（${score} 分），识别结果可信度低，请以药盒说明书为准。`;
      break;
  }

  return {
    status,
    label,
    score,
    correctedDrugName,
    needsSelection: false,
    candidates,
    bestMatch,
    humanNote,
    layer1Note,
    layer2Note,
  };
}

function normalizeCandidate(drug: YiYuanDrug): VerificationCandidate {
  return {
    drugName: drug.drugName || drug.tymc || "",
    genericName: drug.tymc,
    brandName: drug.spmc,
    approvalNumber: drug.pzwh,
    manufacturer: drug.manu,
    specification: drug.gg,
    indications: drug.syz,
    dosage: drug.yfyl,
    contraindications: drug.jj,
    warnings: drug.zysx,
  };
}
