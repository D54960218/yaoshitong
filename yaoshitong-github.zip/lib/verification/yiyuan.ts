/**
 * 万维易源（易源数据）药品信息查询适配器。
 *
 * 调用接口：
 * - 1468-3：按名称/药企/药准字号/药品Id 检索完整说明书
 * - 1468-4：按药名模糊检索说明书
 *
 * AppKey 从服务端环境变量 YIYUAN_APP_KEY 读取，**不会出现在前端**。
 */

import { fetchWithTimeout, safeJson } from "../drug-verification/utils";

const BASE_URL = "https://route.showapi.com";

export interface YiYuanDrug {
  /** 通用名称 */
  tymc?: string;
  /** 商品名称 */
  spmc?: string;
  /** 药品名称（含品牌） */
  drugName?: string;
  /** 批准文号 */
  pzwh?: string;
  /** 生产企业 */
  manu?: string;
  /** 规格 */
  gg?: string;
  /** 适应症 */
  syz?: string;
  /** 用法用量 */
  yfyl?: string;
  /** 禁忌 */
  jj?: string;
  /** 注意事项 */
  zysx?: string;
  /** 不良反应 */
  blfy?: string;
  /** 主要成份 */
  zycf?: string;
  /** 剂型 */
  jx?: string;
  /** 药品分类 */
  fl?: string;
}

interface YiYuanResponse {
  showapi_res_code?: number;
  showapi_res_error?: string;
  showapi_res_body?: {
    ret_code?: string;
    msg?: string;
    drugList?: YiYuanDrug[];
    count?: number;
  };
}

function getAppKey(): string {
  const key = process.env.YIYUAN_APP_KEY;
  if (!key || key.trim() === "" || key.includes("你的") || key.includes("AppKey")) {
    throw new Error("服务器未配置 YIYUAN_APP_KEY，请在 .env.local 中填写真实的易源数据 AppKey");
  }
  return key.trim();
}

/** 公共参数：page / maxResult */
function commonParams(page = 1, maxResult = 10): URLSearchParams {
  const params = new URLSearchParams();
  params.append("page", String(page));
  params.append("maxResult", String(maxResult));
  return params;
}

/** 调用 1468-3：精确检索
 * searchType: 1=药品名称 2=药企名称 3=药准字号 4=药品Id
 */
export async function searchByApprovalNumber(approvalNumber: string): Promise<YiYuanDrug[]> {
  const params = commonParams();
  params.append("searchType", "3");
  params.append("searchKey", approvalNumber);
  return callYiYuan("1468-3", params);
}

/** 调用 1468-4：按药名模糊检索 */
export async function searchByDrugName(drugName: string): Promise<YiYuanDrug[]> {
  const params = commonParams();
  params.append("searchKey", drugName);
  return callYiYuan("1468-4", params);
}

async function callYiYuan(endpoint: string, params: URLSearchParams): Promise<YiYuanDrug[]> {
  const appKey = getAppKey();
  const url = `${BASE_URL}/${endpoint}?appKey=${encodeURIComponent(appKey)}&${params.toString()}`;
  const res = await fetchWithTimeout(url, { method: "GET" }, 15000);
  const data = await safeJson<YiYuanResponse>(res);

  if (!data || data.showapi_res_code !== 0) {
    const err = data?.showapi_res_error || "易源数据接口调用失败";
    throw new Error(err);
  }

  const body = data.showapi_res_body;
  if (!body || body.ret_code !== "0") {
    const err = body?.msg || "易源数据业务返回失败";
    throw new Error(err);
  }

  return body.drugList || [];
}
