/**
 * 药品识别结果可信度评分规则与裁决函数。
 *
 * 设计原则：GLM 只提假设，数据库 API 提供证据，代码负责比对、打分、裁决。
 * 全程不让模型做“是否可信”的判断。
 */

export interface ScoreRules {
  approvalNumberMatch: number; // 批准文号存在且药名匹配
  approvalNumberExists: number; // 批准文号存在但药名不匹配（以数据库为准修正）
  drugNameInDB: number; // 药名在说明书库中存在
  manufacturerMatch: number; // 生产企业匹配
  specificationMatch: number; // 规格匹配
}

export interface Thresholds {
  verified: number;
  partial: number;
  confirm: number;
}

export const SCORE_RULES: ScoreRules = {
  approvalNumberMatch: 40,
  approvalNumberExists: 20,
  drugNameInDB: 25,
  manufacturerMatch: 15,
  specificationMatch: 10,
};

export const THRESHOLDS: Thresholds = {
  verified: 80,
  partial: 50,
  confirm: 30,
};

/** 药名归一化：去掉剂型后缀、括号内容、空格 */
export function normalizeDrugName(name: string): string {
  if (!name) return "";
  return name
    .replace(/[（(].*?[）)]/g, "")
    .replace(/[胶囊片颗粒丸口服液注射液糖浆散膏丹汤饮茶贴]/g, "")
    .replace(/\s+/g, "")
    .trim()
    .toLowerCase();
}

/** 药名模糊匹配：任一包含另一个即视为匹配 */
export function isDrugNameMatch(dbName: string, glmName: string): boolean {
  const a = normalizeDrugName(dbName);
  const b = normalizeDrugName(glmName);
  if (!a || !b) return false;
  return a.includes(b) || b.includes(a);
}

/** 企业名归一化 */
export function normalizeManufacturer(name: string): string {
  if (!name) return "";
  return name
    .replace(/[有限公司制药集团股份]/g, "")
    .replace(/\s+/g, "")
    .trim()
    .toLowerCase();
}

/** 规格归一化：去掉空格、统一大小写 */
export function normalizeSpecification(name: string): string {
  if (!name) return "";
  return name.replace(/\s+/g, "").replace(/[×xX]/g, "*").trim().toLowerCase();
}

/** 企业名模糊匹配 */
export function isManufacturerMatch(dbName: string, glmName: string): boolean {
  const a = normalizeManufacturer(dbName);
  const b = normalizeManufacturer(glmName);
  if (!a || !b) return false;
  return a.includes(b) || b.includes(a);
}

/** 规格模糊匹配 */
export function isSpecificationMatch(dbName: string, glmName: string): boolean {
  const a = normalizeSpecification(dbName);
  const b = normalizeSpecification(glmName);
  if (!a || !b) return false;
  return a.includes(b) || b.includes(a);
}

/** 分级裁决 */
export function getVerdict(score: number): "verified" | "partial" | "confirm" | "rejected" {
  if (score >= THRESHOLDS.verified) return "verified";
  if (score >= THRESHOLDS.partial) return "partial";
  if (score >= THRESHOLDS.confirm) return "confirm";
  return "rejected";
}

/** 把裁决状态翻译成前端展示文案 */
export function verdictLabel(status: ReturnType<typeof getVerdict>): string {
  switch (status) {
    case "verified":
      return "已验证";
    case "partial":
      return "部分验证";
    case "confirm":
      return "需要确认";
    case "rejected":
      return "验证未通过";
    default:
      return "待验证";
  }
}
