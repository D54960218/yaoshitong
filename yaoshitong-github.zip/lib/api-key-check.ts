/**
 * 检查 API Key 是否看起来像真实有效的 Key。
 *
 * 背景：.env.local 里如果还填着中文占位符（如"在这里粘贴你的智谱APIKey"），
 * 直接传给 fetch 的 Authorization header 会因含非 ASCII 字符而抛错，页面直接崩溃。
 * 这里提前拦截，给出人话提示。
 */

export interface KeyCheckResult {
  ok: boolean;
  error?: string;
}

/** 是否只包含 ASCII 可打印字符（空格除外） */
function isAsciiPrintable(s: string): boolean {
  for (const ch of s) {
    const code = ch.charCodeAt(0);
    if (code < 33 || code > 126) return false;
  }
  return true;
}

/** 检查智谱 API Key */
export function checkZhipuKey(apiKey: string | undefined): KeyCheckResult {
  if (!apiKey || apiKey.trim() === "") {
    return { ok: false, error: "服务器还没配置智谱 API Key，请按 README.md 的说明填写 .env.local 后重启" };
  }
  const trimmed = apiKey.trim();
  // 常见占位符（模板里的中文提示）
  if (trimmed.includes("粘贴") || trimmed.includes("你的") || trimmed.includes("APIKey") || trimmed.includes("在这里")) {
    return { ok: false, error: "ZHIPU_API_KEY 还是模板占位符，请把 .env.local 里的中文提示换成真实的智谱 API Key" };
  }
  if (trimmed.length < 8) {
    return { ok: false, error: "ZHIPU_API_KEY 太短，请重新复制完整的智谱 API Key" };
  }
  if (!isAsciiPrintable(trimmed)) {
    return { ok: false, error: "ZHIPU_API_KEY 含有中文或特殊字符，请检查 .env.local 里是否还留着模板占位符" };
  }
  return { ok: true };
}

/** 检查 MiniMax API Key */
export function checkMinimaxKey(apiKey: string | undefined): KeyCheckResult {
  if (!apiKey || apiKey.trim() === "") {
    return { ok: false, error: "服务器还没配置 MiniMax API Key，语音播报功能会不可用，请按 README.md 填写 .env.local 后重启" };
  }
  const trimmed = apiKey.trim();
  if (trimmed.includes("粘贴") || trimmed.includes("你的") || trimmed.includes("APIKey") || trimmed.includes("在这里")) {
    return { ok: false, error: "MINIMAX_API_KEY 还是模板占位符，如需语音播报请换成真实的 MiniMax API Key" };
  }
  if (!isAsciiPrintable(trimmed)) {
    return { ok: false, error: "MINIMAX_API_KEY 含有中文或特殊字符，请检查 .env.local 里是否还留着模板占位符" };
  }
  return { ok: true };
}
